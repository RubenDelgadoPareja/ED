#include "pila_max.h"
#if CUAL_COMPILA==1
#include <pila_max_vd.cpp>
#elif CUAL_COMPILA==2
#include <pila_max_cola.cpp>
#endif
