#include <iostream>
#include "imagen.h"
#include "imagenES.h"
#include <math.h>

using namespace std;

Imagen::Imagen(){};

Imagen::Imagen(const Imagen & J){
    this->copy(J);
};

Imagen::Imagen(int filas, int cols){
    if(filas > 0 && cols > 0){
        this->filas = filas;
        this->cols = cols;
        img = new byte*[filas];
        for(int i=0; i<filas; i++)
            img[i] = new byte[cols];
    }
};
Imagen::Imagen(int filas,int cols, const unsigned char * vector){
    if(filas > 0 && cols > 0){
        this->filas = filas;
        this->cols = cols;
        img = new byte*[filas];
        for(int i=0; i<filas; i++)
            img[i] = new byte[cols];

        int k=0;
        for(int i=0; i<filas; i++){
            for(int j=0; j<cols; j++){
                img[i][j]=vector[k];
                k++;
            }
        }

    }
}

Imagen::~Imagen(){
    this->filas = 0;
    this->cols = 0;
    this->limpiar();
};

unsigned char * Imagen::Convertir(){
    unsigned char * imagen = new unsigned char[this->num_filas()*this->num_columnas()];

    int k=0;
    for(int i=0; i<this->num_filas(); i++){
        for(int j=0; j<this->num_columnas();j++){
            imagen[k] = this->valor_pixel(i,j);
            k++;
        }
    }
    return imagen;
};

int Imagen::num_filas() const{
    return this->filas;
};

int Imagen::num_columnas() const{
    return this->cols;
};

void Imagen::asigna_pixel(int fila,int col, byte valor){
    if(0 <= filas < num_filas() && 0 <= col < num_columnas() && 0<= valor <=255)  
        this->img[fila][col] = valor;   
};

byte Imagen::valor_pixel(int fila,int col) const{
    byte valor = -1;
    if(0 <= filas < num_filas() && 0 <= col < num_columnas())
        valor = this->img[fila][col];
    return valor;    
};

Imagen & Imagen::operator=(const Imagen & J){
    if(this != &J){
        this->limpiar();
        this->copy(J);
    }
};

void Imagen::limpiar(){
    for(int i=0; i<this->num_filas(); i++){
        delete []img[i];
    }
    delete []img;
};

void Imagen::copy(const Imagen & im){
    this->filas = im.num_filas();
    this->cols = im.num_columnas();
    this->img = new byte*[filas];
    for(int i=0; i<cols; i++)
        this->img[i] = new byte[cols];

    for(int i=0; i<filas; i++){
        for(int j=0; j<cols; j++){
            this->asigna_pixel(i,j,im.valor_pixel(i,j));
        }
    }
};

void Umbralizar(const char *entrada, const char *salida,int T1,int T2){
    unsigned char *imagen;
    int nf, nc, npixeles;
    npixeles = nf*nc;
    imagen = LeerImagenPGM(entrada,nf,nc);

    if (!imagen){
        cerr << "Error: No pudo leerse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        exit (1);
    }
    
    Imagen img(nf,nc,imagen);

   for (int i=0; i<nf; i++){
        for(int j=0; j<nc; j++){
            if( img.valor_pixel(i,j) < T1 || img.valor_pixel(i,j) > T2  )
                img.asigna_pixel(i,j,255);
        }
    }

    if (EscribirImagenPGM(salida, img.Convertir(), nf,nc))
        cout  << "La imagen se guardo en " << salida << endl;
    else{
        cerr << "Error: No pudo guardarse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        exit (2);
    }

    delete [] imagen;
};


void Zoom(const char* entrada, const char* salida, int x_1, int y_1, int x_2, int y_2) {

	int nf = 0 , nc = 0;
	double media = 0;
    int cont_1 = 0, cont_2 = 0;
	int nfil = x_2 - x_1 + 1;
	int ncol = y_2 - y_1 + 1;
	unsigned char* img;

	if (nfil == ncol) { //Requisitos para hacer zoom, que sea cuadrada

		TipoImagen tipo = LeerTipoImagen(entrada);

		img = LeerImagenPGM(entrada, nf, nc);

        cout<<"filas :"<<nf<<endl;
        cout<<"columnas :"<<nc<<endl;

        //creamos una instancia de la clase Imagen con los datos del vector que guarda la imagen
		Imagen imagen(nf, nc, img);
	
        //creamos una imagen auxiliar para guardar la parte donde haremos zoom
		Imagen aux(nfil, ncol);
        cont_1 = 0;
		for (int i = x_1; i <= x_2; i++) { 
			for (int j = y_1; j <= y_2; j++) { 
				aux.asigna_pixel(cont_1, cont_2, imagen.valor_pixel(i,j));
				cont_2++;
			}
			cont_2=0;
			cont_1++;
		}

		//en caso de ser una imagen PGM podremos interpolar 
		if (tipo == IMG_PGM) {
			
			//Creamos otra imagen auxiliar para interpolar las columnas
			Imagen aux_col(aux.num_filas(),2*aux.num_columnas() - 1);

			cont_1 = 0;
            cont_2 = 0;
			
			for (int i = 0; i < aux.num_filas() - 1; i++) {
				for (int j = 0; j < aux.num_columnas() - 1; j++) {
					media = (aux.valor_pixel(i, j) + aux.valor_pixel(i, j+1))/2;
					aux_col.asigna_pixel(cont_1, cont_2, aux.valor_pixel(i, j));
					cont_2++;
					aux_col.asigna_pixel(cont_1, cont_2, round(media));
					cont_2++;
					aux_col.asigna_pixel(cont_1, cont_2, aux.valor_pixel(i, j+1)); 	
				}
				cont_2 = 0;
				cont_1++;
			}

			Imagen aux_filas(2*aux.num_filas() - 1, aux_col.num_columnas());


			//Creamos otra imagen auxiliar para interpolar las filas
			media = 0;
            cont_1 = 0;
            cont_2 = 0;
			for (int i = 0; i < aux_col.num_columnas() - 1; i++) {
				for (int j = 0; j < aux_col.num_filas() - 1; j++) {
					media = (aux_col.valor_pixel(j, i) + aux_col.valor_pixel(j+1, i))/2;
					aux_filas.asigna_pixel(cont_1, cont_2, aux_col.valor_pixel(j, i));
					cont_1++;					
					aux_filas.asigna_pixel(cont_1, cont_2, round(media));
					cont_1++;
					aux_filas.asigna_pixel(cont_1, cont_2, aux_col.valor_pixel(j+1, i)); 
				}
				cont_1 = 0;
				cont_2++;
			}
			

			EscribirImagenPGM(salida, aux_filas.Convertir(), aux_filas.num_filas(), aux_filas.num_columnas()); 

			//delete[] final;
		}

	}
	delete[] img;

    
};

void Contraste(const char* entrada, const char* salida, byte min, byte max){


    int nf, nc;
    unsigned char * imagen;
    imagen = LeerImagenPGM(entrada, nf, nc );

    double menor = 255;
    double mayor = 0;

    for(int i=0; i<nf*nc; i++){
        if( menor > imagen[i])
            menor = imagen[i];
        if( mayor < imagen[i])
            mayor = imagen[i];
    }

    double constante = (double(max) - double(min))/(mayor - menor);
    double valor = 0;

    
    Imagen img(nf,nc,imagen);
    //EscribirImagenPGM(salida, img.Convertir(), img.num_filas(), img.num_columnas());

    for(int i=0; i<nf; i++){
        for(int j=0; j<nc; j++){
            valor = double(min) + ( constante * (double(img.valor_pixel(i,j)) - menor ) );
            //cout<<constante<<endl;
            if( valor > max )
                img.asigna_pixel(i,j, max);
            else if( valor < min)
                img.asigna_pixel(i,j,min);
            else
                img.asigna_pixel(i,j, round(valor));
        }
    }

    EscribirImagenPGM(salida, img.Convertir(), img.num_filas(), img.num_columnas()); 

    delete[] imagen;

};
